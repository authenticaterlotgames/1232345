document.addEventListener('DOMContentLoaded', function() {
  const links = document.querySelectorAll('.anime-link');
  links.forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault(); // Previne a ação padrão do link
      chrome.tabs.create({ url: this.href }); // Abre o link na nova guia
    });
  });
});
